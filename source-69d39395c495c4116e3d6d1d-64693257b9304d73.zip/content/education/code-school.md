---
school: School Education
summary: Completed schooling up to Class 8th
startDate: 2012-01-01
endDate: 2020-12-31
tags:
  [
    "Mathematics",
    "Science",
    "English",
    "Social Studies",
    "Hindi",
    "Computer Science",
  ]
---

Completed all subjects through Class 8th including Mathematics, Science, English, Social Studies, Hindi, and Computer Science.
