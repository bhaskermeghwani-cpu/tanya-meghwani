
export default [
  {
    "school": "School Education",
    "summary": "Completed schooling up to Class 8th",
    "startDate": "2012-01-01",
    "endDate": "2020-12-31",
    "tags": [
      "Mathematics",
      "Science",
      "English",
      "Social Studies",
      "Hindi",
      "Computer Science"
    ],
    "content": "Completed all subjects through Class 8th including Mathematics, Science, English, Social Studies, Hindi, and Computer Science.",
    "_meta": {
      "filePath": "code-school.md",
      "fileName": "code-school.md",
      "directory": ".",
      "extension": "md",
      "path": "code-school"
    }
  }
]