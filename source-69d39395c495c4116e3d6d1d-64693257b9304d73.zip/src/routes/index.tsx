import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import {
  GraduationCap,
  Star,
  Users,
  BookOpen,
  CheckCircle,
  Monitor,
  Home,
  Phone,
  User,
  Layers,
  FlaskConical,
} from 'lucide-react'

export const Route = createFileRoute('/')({
  component: HomePage,
})

function encode(data: Record<string, string>) {
  return Object.entries(data)
    .map(([key, val]) => `${encodeURIComponent(key)}=${encodeURIComponent(val)}`)
    .join('&')
}

function HomePage() {
  const [form, setForm] = useState({
    studentName: '',
    class: '',
    subject: '',
    phone: '',
    mode: 'Home Tuition',
  })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    await fetch('/student-registration.html', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: encode({ 'form-name': 'student-registration', ...form }),
    })
    setLoading(false)
    setSubmitted(true)
  }

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-indigo-600 via-indigo-700 to-purple-800 text-white py-24 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-white/20 text-white text-sm font-medium px-4 py-2 rounded-full mb-6 backdrop-blur-sm">
            <Star className="w-4 h-4 fill-yellow-300 text-yellow-300" />
            Trusted by 100+ Students
          </div>
          <h1 className="text-5xl md:text-6xl font-extrabold mb-4 leading-tight">
            Tanya Meghwani
          </h1>
          <p className="text-2xl md:text-3xl font-light text-indigo-200 mb-6">
            Expert Maths &amp; Science Home Tutor
          </p>
          <p className="text-lg text-indigo-100 max-w-2xl mx-auto mb-10">
            Personalized, result-oriented tutoring for Classes 6-12. Build
            confidence, master concepts, and achieve academic excellence.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#register"
              className="px-8 py-4 bg-white text-indigo-700 font-bold rounded-xl hover:bg-indigo-50 transition-colors shadow-lg text-lg"
            >
              Register Now
            </a>
            <a
              href="#about"
              className="px-8 py-4 bg-white/20 text-white font-bold rounded-xl hover:bg-white/30 transition-colors backdrop-blur-sm text-lg border border-white/30"
            >
              Learn More
            </a>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="bg-white shadow-sm py-8 px-4">
        <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {[
            { icon: Users, value: '100+', label: 'Students Taught' },
            { icon: GraduationCap, value: '8+', label: 'Years Experience' },
            { icon: BookOpen, value: '2', label: 'Core Subjects' },
            { icon: Star, value: '98%', label: 'Success Rate' },
          ].map(({ icon: Icon, value, label }) => (
            <div key={label} className="flex flex-col items-center gap-2">
              <Icon className="w-8 h-8 text-indigo-500" />
              <p className="text-3xl font-bold text-gray-900">{value}</p>
              <p className="text-sm text-gray-500">{label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-gray-50">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
              About Tanya
            </h2>
            <p className="text-gray-500 text-lg max-w-xl mx-auto">
              Passionate educator dedicated to unlocking every student's potential
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div className="bg-gradient-to-br from-indigo-100 to-purple-100 rounded-2xl p-8 flex flex-col items-center justify-center text-center min-h-64">
              <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full flex items-center justify-center mb-4 shadow-lg">
                <GraduationCap className="w-12 h-12 text-white" />
              </div>
              <h3 className="text-xl font-bold text-indigo-800">Tanya Meghwani</h3>
              <p className="text-indigo-600 font-medium mt-1">M.Sc. Mathematics</p>
              <p className="text-gray-500 text-sm mt-2">Maths and Science Tutor since 2016</p>
            </div>

            <div className="space-y-5">
              <p className="text-gray-700 text-lg leading-relaxed">
                With over 8 years of teaching experience, Tanya Meghwani brings
                a patient, structured approach to Maths and Science education.
                Her methodology focuses on building strong foundational
                understanding rather than rote memorization.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Tanya specializes in making complex topics approachable through
                real-world examples, step-by-step problem solving, and regular
                practice sessions tailored to each student's learning pace.
              </p>
              <div className="space-y-3 pt-2">
                {[
                  'Personalized study plans for every student',
                  'Regular progress assessments and parent updates',
                  'Flexible home tuition and online sessions',
                  'Exam preparation and doubt-clearing sessions',
                ].map((point) => (
                  <div key={point} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-indigo-500 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{point}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Subjects Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 text-center mb-10">
            Subjects Offered
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="bg-indigo-50 border border-indigo-100 rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center">
                  <Layers className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Mathematics</h3>
              </div>
              <ul className="space-y-2">
                {['Algebra and Geometry', 'Trigonometry', 'Calculus (Class 11-12)', 'Statistics and Probability', 'Board Exam Preparation'].map((t) => (
                  <li key={t} className="flex items-center gap-2 text-gray-700">
                    <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full flex-shrink-0" />
                    {t}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-purple-50 border border-purple-100 rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-purple-600 rounded-xl flex items-center justify-center">
                  <FlaskConical className="w-5 h-5 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900">Science</h3>
              </div>
              <ul className="space-y-2">
                {['Physics', 'Chemistry', 'Biology (Class 6-10)', 'Practical Concepts', 'NCERT and Reference Books'].map((t) => (
                  <li key={t} className="flex items-center gap-2 text-gray-700">
                    <span className="w-1.5 h-1.5 bg-purple-500 rounded-full flex-shrink-0" />
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Registration Form */}
      <section id="register" className="py-20 px-4 bg-gradient-to-br from-indigo-50 to-purple-50">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
              Student Registration
            </h2>
            <p className="text-gray-500 text-lg">
              Fill in the details below to enroll with Tanya Tutor
            </p>
          </div>

          {submitted ? (
            <div className="bg-white rounded-2xl shadow-lg p-10 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-9 h-9 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">
                Registration Successful!
              </h3>
              <p className="text-gray-600 mb-6">
                Thank you for registering. Tanya will contact you shortly on
                your provided phone number to discuss scheduling and session details.
              </p>
              <button
                onClick={() => {
                  setSubmitted(false)
                  setForm({ studentName: '', class: '', subject: '', phone: '', mode: 'Home Tuition' })
                }}
                className="px-6 py-3 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition-colors font-medium"
              >
                Register Another Student
              </button>
            </div>
          ) : (
            <form
              name="student-registration"
              onSubmit={handleSubmit}
              className="bg-white rounded-2xl shadow-lg p-8 space-y-6"
            >
              <input type="hidden" name="form-name" value="student-registration" />

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  <User className="inline w-4 h-4 mr-1 text-indigo-500" />
                  Student Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="studentName"
                  value={form.studentName}
                  onChange={handleChange}
                  required
                  placeholder="Enter full name"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 outline-none transition-all bg-gray-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  <GraduationCap className="inline w-4 h-4 mr-1 text-indigo-500" />
                  Class / Grade <span className="text-red-500">*</span>
                </label>
                <select
                  name="class"
                  value={form.class}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 outline-none transition-all bg-gray-50 focus:bg-white"
                >
                  <option value="">Select class</option>
                  {['6', '7', '8', '9', '10', '11', '12'].map((c) => (
                    <option key={c} value={"Class " + c}>
                      Class {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  <BookOpen className="inline w-4 h-4 mr-1 text-indigo-500" />
                  Subject <span className="text-red-500">*</span>
                </label>
                <select
                  name="subject"
                  value={form.subject}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 outline-none transition-all bg-gray-50 focus:bg-white"
                >
                  <option value="">Select subject</option>
                  <option value="Mathematics">Mathematics</option>
                  <option value="Science">Science</option>
                  <option value="Mathematics and Science">Mathematics and Science (Both)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  <Phone className="inline w-4 h-4 mr-1 text-indigo-500" />
                  Phone Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={form.phone}
                  onChange={handleChange}
                  required
                  placeholder="+91 XXXXX XXXXX"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 outline-none transition-all bg-gray-50 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Tutoring Mode <span className="text-red-500">*</span>
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <label
                    className={"flex flex-col items-center gap-2 p-4 border-2 rounded-xl cursor-pointer transition-all " + (form.mode === 'Home Tuition' ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200 bg-gray-50 hover:border-indigo-200')}
                  >
                    <input
                      type="radio"
                      name="mode"
                      value="Home Tuition"
                      checked={form.mode === 'Home Tuition'}
                      onChange={handleChange}
                      className="sr-only"
                    />
                    <Home className={"w-6 h-6 " + (form.mode === 'Home Tuition' ? 'text-indigo-600' : 'text-gray-400')} />
                    <span className={"font-semibold text-sm " + (form.mode === 'Home Tuition' ? 'text-indigo-700' : 'text-gray-700')}>Home Tuition</span>
                    <span className="text-xs text-gray-500 text-center">Tutor visits your home</span>
                  </label>
                  <label
                    className={"flex flex-col items-center gap-2 p-4 border-2 rounded-xl cursor-pointer transition-all " + (form.mode === 'Online' ? 'border-indigo-500 bg-indigo-50' : 'border-gray-200 bg-gray-50 hover:border-indigo-200')}
                  >
                    <input
                      type="radio"
                      name="mode"
                      value="Online"
                      checked={form.mode === 'Online'}
                      onChange={handleChange}
                      className="sr-only"
                    />
                    <Monitor className={"w-6 h-6 " + (form.mode === 'Online' ? 'text-indigo-600' : 'text-gray-400')} />
                    <span className={"font-semibold text-sm " + (form.mode === 'Online' ? 'text-indigo-700' : 'text-gray-700')}>Online</span>
                    <span className="text-xs text-gray-500 text-center">Learn from anywhere</span>
                  </label>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold rounded-xl hover:from-indigo-700 hover:to-purple-700 transition-all shadow-md hover:shadow-lg disabled:opacity-60 disabled:cursor-not-allowed text-lg"
              >
                {loading ? 'Submitting...' : 'Submit Registration'}
              </button>

              <p className="text-xs text-gray-400 text-center">
                Your information is kept private and will only be used to contact you about tutoring sessions.
              </p>
            </form>
          )}
        </div>
      </section>
    </div>
  )
}
