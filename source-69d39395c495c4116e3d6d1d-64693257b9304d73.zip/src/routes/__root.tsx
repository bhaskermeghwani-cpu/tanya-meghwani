import { HeadContent, Outlet, Scripts, createRootRoute, Link } from '@tanstack/react-router'
import { useState } from 'react'
import { Menu, X, BookOpen } from 'lucide-react'

import '../styles.css'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      {
        charSet: 'utf-8',
      },
      {
        name: 'viewport',
        content: 'width=device-width, initial-scale=1',
      },
      {
        title: 'Tanya Tutor | Maths & Science Home Tutor',
      },
    ],
  }),
  shellComponent: RootDocument,
  component: RootLayout,
})

function RootLayout() {
  return <Outlet />
}

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        <SiteLayout>{children}</SiteLayout>
        <Scripts />
      </body>
    </html>
  )
}

function SiteLayout({ children }: { children: React.ReactNode }) {
  const [mobileOpen, setMobileOpen] = useState(false)

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 text-indigo-700 font-bold text-xl">
            <BookOpen className="w-6 h-6" />
            Tanya Tutor
          </Link>
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-600">
            <Link to="/" className="hover:text-indigo-600 transition-colors [&.active]:text-indigo-700 [&.active]:font-semibold">Home</Link>
            <a href="/#about" className="hover:text-indigo-600 transition-colors">About</a>
            <a href="/#register" className="hover:text-indigo-600 transition-colors">Register</a>
            <a
              href="/#register"
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Enroll Now
            </a>
          </div>
          <button
            className="md:hidden text-gray-600 hover:text-indigo-600"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
        {mobileOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 px-4 py-3 space-y-2">
            <Link to="/" className="block py-2 text-gray-700 hover:text-indigo-600" onClick={() => setMobileOpen(false)}>Home</Link>
            <a href="/#about" className="block py-2 text-gray-700 hover:text-indigo-600" onClick={() => setMobileOpen(false)}>About</a>
            <a href="/#register" className="block py-2 text-gray-700 hover:text-indigo-600" onClick={() => setMobileOpen(false)}>Register</a>
          </div>
        )}
      </nav>
      <main>{children}</main>
      <footer className="bg-gray-900 text-gray-400 text-center py-8 text-sm mt-16">
        <p className="font-medium text-gray-300 mb-1">Tanya Meghwani · Tanya Tutor</p>
        <p>Expert Maths &amp; Science Home Tutor</p>
        <p className="mt-2">© {new Date().getFullYear()} All rights reserved.</p>
      </footer>
    </div>
  )
}
